package com.example.sidebarprototype;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class SidebarService extends Service {
    WindowManager wm;
    LinearLayout panel;
    WindowManager.LayoutParams params;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8),dp(12),dp(8),dp(12));
        panel.setBackgroundColor(Color.rgb(30,30,36));

        Button handle = new Button(this);
        handle.setText("☰");
        handle.setTextSize(18);
        handle.setOnClickListener(v -> toggleButtons());

        Button yt = new Button(this);
        yt.setText("▶ YouTube");
        yt.setOnClickListener(v -> openUrl("https://www.youtube.com/"));

        Button tt = new Button(this);
        tt.setText("♪ TikTok");
        tt.setOnClickListener(v -> openUrl("https://www.tiktok.com/"));

        Button close = new Button(this);
        close.setText("✕");
        close.setOnClickListener(v -> stopSelf());

        panel.addView(handle);
        panel.addView(yt);
        panel.addView(tt);
        panel.addView(close);

        params = new WindowManager.LayoutParams(
            dp(145), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
        params.x = 0;
        params.y = 0;

        wm.addView(panel, params);
    }

    void toggleButtons() {
        for (int i=1; i<panel.getChildCount()-1; i++) {
            View v=panel.getChildAt(i);
            v.setVisibility(v.getVisibility()==View.VISIBLE ? View.GONE : View.VISIBLE);
        }
    }

    void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch(Exception ignored) {}
    }

    @Override public void onDestroy() {
        if (panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
