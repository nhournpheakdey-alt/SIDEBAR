package com.example.sidebarprototype;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40,40,40,40);

        TextView title = new TextView(this);
        title.setText("🎮 Game Sidebar Prototype");
        title.setTextSize(26);
        title.setTextColor(Color.BLACK);

        TextView info = new TextView(this);
        info.setText("\nThis prototype puts a small sidebar over your game.\n\nAndroid requires overlay permission for this feature.");
        info.setTextSize(17);

        Button permission = new Button(this);
        permission.setText("Allow Display Over Other Apps");
        permission.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });

        Button start = new Button(this);
        start.setText("🚀 Start Sidebar");
        start.setOnClickListener(v -> {
            startService(new Intent(this, SidebarService.class));
            finish();
        });

        box.addView(title);
        box.addView(info);
        box.addView(permission);
        box.addView(start);
        setContentView(box);
    }
}
