# Game Sidebar Prototype

This is a small Android 14-friendly prototype.

## What it does
- Requests Android "Display over other apps" permission.
- Starts a small sidebar overlay that can remain visible over a game.
- Buttons open YouTube or TikTok using Android's normal app/browser handling.
- The sidebar can be collapsed/expanded and closed.

## Important limitation
This prototype does NOT embed TikTok or YouTube inside the overlay. Android and those apps control whether their content can appear in a floating window. Opening them normally may switch to their app instead of creating a true floating video window.

## Build
Open this folder in Android Studio and let Gradle sync, then Build > Build APK(s).

## Install
Install the generated debug APK on the Android 14 phone, open it, grant "Display over other apps", then press Start Sidebar.
